import random
#𒁲𒈠𒃶𒈨𒂗
# Oyun tahtasının boyutunu al
board_size = int(input("Lütfen oyun tahtasının boyutunu girin: "))

# Oyun tahtasını oluştur ve rastgele doldur
board = []
for i in range(board_size):
  row = []
  for j in range(board_size):
    row.append(random.randint(1, 9))
  board.append(row)

# Oyun tahtasını göster
for row in board:
  print(row)

# Tahmin etme oyunu
while True:
  # Kullanıcıdan satır ve sütun indekslerini al
  row = int(input("Lütfen tahmin edilecek satır indeksini girin (0-" + str(board_size-1) + "): "))
  col = int(input("Lütfen tahmin edilecek sütun indeksini girin (0-" + str(board_size-1) + "): "))

  # Tahmin edilen hücrenin değerini al ve kullanıcıya bildir
  guess = board[row][col]
  print("Tahmin ettiğiniz hücre değeri:", guess)

  # Kullanıcının tahmin etmeyi sürdürüp sürdürmeyeceğini sor
  continue_playing = input("Tahmin etmeyi sürdürmek istiyor musunuz? (e/h): ")
  if continue_playing.lower() != 'e':
    break

print("Oyun bitti, teşekkürler!")
    #Doğancan ÖZGÖKÇELER 25/12/2022